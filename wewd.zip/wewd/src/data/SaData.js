const SaData = [
    {
        id: 1,
        name: "Patanjali Nutrela Iron Complex Natural",
        price: "₹ 135",
        img: "https://www.patanjaliayurved.net/assets/product_images/400x500/1707987821ironc1.png",
        rew: "⭐ ⭐ ⭐",
        Des: "Nutrela Iron Complex Natural is 100% Vegan & Natural Iron supplement for Vegans and Non Vegans. It is Gluten Free, GMO Free with no added color and preservative free. Helps you to meet 100% RDA of Iron. Patanjali Nutrela Iron Complex Natural is a dietary supplement designed to support overall health by providing essential iron and other vital nutrients. This supplement is formulated with natural ingredients to ensure maximum absorption and effectiveness. Key components include iron, folic acid, and vitamin B12, which are crucial for the production of red blood cells and the prevention of anemia. Additionally, it contains natural extracts like amla and spinach, which are rich in vitamins and minerals. Patanjali Nutrela Iron Complex Natural is suitable for individuals looking to boost their iron levels, improve energy, and maintain overall well-being. It is free from artificial additives and is a safe choice for daily supplementation."
    },
    {
        id: 2,
        name: "Patanjali Kesh Kanti Hair Oil Unisex",
        price: "₹ 128",
        rew: "⭐ ⭐ ⭐ ⭐",
        img: "https://www.patanjaliayurved.net/assets/product_images/400x500/1689500964KeshkantiHairOil120ml1.png",
        Des: "Hair nutrition is an essential aspect of maintaining optimal hair health for individuals. Patanjali Kesh Kanti Advanced Herbal Hair Expert Oil presents a viable solution to a range of hair-related issues. This product is formulated using approximately 30 valuable herbs, including Bhringraj, Kalonji, Ghrit Kumari, Manjistha, Amla, Malkangani, Shikakai, Reetha, and Brahmi.Patanjali Kesh Kanti Hair Oil is a unisex hair care product designed to promote healthy, strong, and lustrous hair. Formulated with a blend of natural herbs and oils, this hair oil aims to nourish the scalp, reduce hair fall, and improve hair texture. Ingredients such as amla, bhringraj, neem, and sesame oil work together to strengthen hair roots, prevent dandruff, and add shine. Suitable for all hair types, Patanjali Kesh Kanti Hair Oil can be used regularly to maintain optimal hair health and vitality. Its non-greasy formula ensures easy application and absorption, leaving hair feeling soft and manageable without any residue"
    },
    {
        id: 3,
        name: "Patanjali Nutrela Slim Choice Powder",
        price: "₹1126",
        rew: "⭐ ⭐ ⭐ ",
        img: "https://www.patanjaliayurved.net/assets/product_images/400x500/17198156391.png",
        Des: "Useful in rejuvenating, nourishing & beautifying skin. Also use as anti–tan pack. Useful in dryness and roughness of skin. Useful in dandruff & hair fall solution. Reduces dark spots & improves skin glow.Patanjali Nutrela Slim Choice Powder is a dietary supplement designed to aid in weight management and support overall health. Enriched with a blend of natural ingredients, it offers a balanced approach to slimming by providing essential nutrients that promote satiety and energy levels. This powder combines the benefits of fiber, vitamins, and minerals, making it an ideal addition to a healthy diet and exercise regimen. It is formulated to support metabolism and help control cravings, making the journey to a healthier weight more manageable and sustainable. Patanjali, known for its commitment to natural and herbal products, ensures that Nutrela Slim Choice Powder is free from harmful additives, providing a wholesome option for those seeking to maintain or achieve their desired weight."
    },
    {
        id: 4,
        name: "Patanjali Saundarya Aloe Vera Gel",
        price: "₹ 96",
        rew: "⭐ ⭐ ⭐ ⭐ ",
        img: "https://www.patanjaliayurved.net/assets/product_images/400x500/1700202042aloeveragel150ml1.png",
        Des: "Patanjali Saundarya Aloe Vera Gel is a versatile skincare product renowned for its soothing and healing properties. Infused with the goodness of pure aloe vera, this gel is designed to provide a natural solution for various skin concerns. It helps hydrate and moisturize the skin, leaving it feeling soft and refreshed. The gel can be used to treat sunburns, acne, and minor cuts, promoting faster healing and reducing inflammation. Additionally, its lightweight, non-greasy formula makes it suitable for all skin types, offering a cooling effect that calms irritated skin. Patanjali ensures that the Saundarya Aloe Vera Gel is free from harmful chemicals, making it a safe and effective choice for daily skincare. Whether used as a moisturizer, a base for makeup, or a soothing treatment for skin issues, this gel is a must-have in any skincare routine."
    },
];

export default SaData;
