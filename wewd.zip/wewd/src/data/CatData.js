const CaData=[
    {
        id:1,
        name:"Health",
        img:"https://www.patanjaliayurved.net/media/images/health-care-icon.webp"
    },
    {
        id:2,
        name:"Natural Personal Care",
        img:"https://www.patanjaliayurved.net/media/images/natural-personal-care.webp"
    },    {
        id:3,
        name:"Medicines",
        img:"https://www.patanjaliayurved.net/media/images/medicine-icon.webp"
    },    {
        id:4,
        name:"Nutraceuticals",
        img:"https://www.patanjaliayurved.net/media/images/naturals-icon.webp"
    },    {
        id:5,
        name:"Paridhan",
        img:"https://www.patanjaliayurved.net/media/images/paridhan-icon.webp"
    },    {
        id:6,
        name:"Publications",
        img:"https://www.patanjaliayurved.net/media/images/publication-icon.webp"
    },
]
export default CaData;