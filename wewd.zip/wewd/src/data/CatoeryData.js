const catogerydata=[
    {
        id:1,
        name:"Hearbel Home Care",
        img:"https://www.patanjaliayurved.net/assets/product_images/400x500/1697699428SuperDishwashgelwithrakhandlemon250ml1.png"
    },  
    {
        id:2,
        name:"Natural Food Products",
        img:"https://www.patanjaliayurved.net/assets/product_images/400x500/1690959764Moongdaldhuli1kg1.png"
    },
    {
        id:3,
        name:"Organic Agri Products",
        img:"https://www.patanjaliayurved.net/assets/product_images/400x500/1691213997FasalTara500mlf.png"
    },
    {
        id:4,
        name:"Stationery",
        img:"https://www.patanjaliayurved.net/assets/product_images/400x500/1693827334(13)PurpleLineNotebook-18x24cm.png"
    },

    
]
export default catogerydata;