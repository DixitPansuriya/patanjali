    const HerData=[
    {
        id:1,
        name:"Pantanjali Super Dish Wash Bar-225",
        price:"₹ 66",
        img:"https://www.patanjaliayurved.net/assets/product_images/400x500/1688706199SuperDishwash225gB3G11.png",
        mrp:"72",
        qunti:"225G",
        rew:"⭐⭐⭐⭐",
        Des:"Lemon combined with wood ash naturally acts as a superior cleansing and disinfecting agent. It's an organic product and made of non-toxic and natural ingredients. This soap doesn't contain any artificial additives like colors, fragrances, enzymes, bleaches or harmful chemicals. Ideal for all types of dishes including ceramic and non-stick ware.  It act as a natural & superior cleaning agent and disinfectant.Soda Ash Light(Sodium Carbonate)Labsa(Dodecylbenzene Sulfonic Acid)Lemon Peel Oil (Citrus Limon)Neem Extract (Azadirachta Indica)Wood Ash"
    },
    {
        id:2,
        name:"Pantanjali Super Steel Scrub scrub pad",
        price:"₹ 16 ",
        img:"https://www.patanjaliayurved.net/assets/product_images/400x500/1688705331StainlessSTEELScrub1.png",
        mrp:"20",
        qunti:"15G",
        rew:"⭐⭐⭐",
        Des:"Patanjali Super Steel Scrub made of the finest grade of stainless steel and Patanjali Scrub Pad has a uniform coating of ALO. which helps in quick superior and also helps remove dirt and greasy materials from utensils.  Non Rust Long LastingSoft for handsTough for stains 430 grade stainless steel. For better result, use with Patanjali Super Dish wash Bar or Gel. Best before 5 years from manufacturing date."
    },
    {
        id:3,
        name:"Pantanjali Super Dishwash Gel Rakh & Lemon",
        price:"₹ 46 ",
        img:"https://www.patanjaliayurved.net/assets/product_images/400x500/1697699428SuperDishwashgelwithrakhandlemon250ml1.png",
        mrp:"50",
        qunti:"250ML",
        rew:"⭐⭐⭐⭐",
        Des:"Patanjali Super Dishwash Gel Raksh & Lemon is a powerful and effective dishwashing solution designed to tackle tough grease and stains with ease. Enriched with the natural cleansing properties of lemon, this gel ensures a sparkling clean finish for all your dishes, pots, and pans. The addition of raksh (ash) enhances its scrubbing power, making it particularly effective against stubborn residues without causing damage to your utensils. Patanjali’s dishwash gel is formulated to be gentle on the hands, minimizing dryness and irritation often associated with dishwashing. Its pleasant lemon fragrance leaves your kitchenware smelling fresh and clean. Free from harsh chemicals, Patanjali Super Dishwash Gel Raksh & Lemon provides a natural, eco-friendly option for maintaining hygiene in your kitchen, reflecting the brand’s commitment to quality and sustainability."
    },
    {
        id:4,
        name:"Glistine Glass Cleaner",
        price:"₹ 79 ",
        img:"https://www.patanjaliayurved.net/assets/product_images/400x500/1701414171glistine1.png",
        mrp:"95",
        qunti:"500ML",
        rew:"⭐⭐⭐⭐",
        Des:"Patanjali Glistine Glass Cleaner is a highly effective cleaning solution designed to keep your glass surfaces sparkling clean and streak-free. Formulated with natural ingredients, this glass cleaner effortlessly removes dirt, dust, and grime from windows, mirrors, and other glass surfaces. Its powerful cleaning action ensures a crystal-clear finish, enhancing the appearance of your home or office. The cleaner is easy to use, requiring just a simple spray and wipe to achieve excellent results. Patanjali Glistine Glass Cleaner is not only tough on stains but also gentle on surfaces, ensuring no damage or scratches occur. Free from harsh chemicals, it provides a safer and more environmentally friendly option for maintaining cleanliness. With a fresh, pleasant fragrance, this glass cleaner leaves your spaces looking pristine and smelling fresh, reflecting Patanjali’s dedication to quality and natural solutions"
    },
    {
        id:5,
        name:"Patanjali Green Flush Toilet Clear Clener(HCL Free)",
        price:"₹ 83 ",
        img:"https://www.patanjaliayurved.net/assets/product_images/400x500/1703581834GREENFLUSHHCLFree1.png",
        mrp:"100",
        qunti:"500ML",
        rew:"⭐⭐⭐⭐⭐",
        Des:"Patanjali Green Flush Toilet Cleaner (HCL Free) is a powerful and eco-friendly solution for maintaining toilet hygiene. Formulated without harmful hydrochloric acid (HCL), this cleaner effectively removes tough stains, limescale, and germs from toilet bowls, leaving them sparkling clean and sanitized. Its natural ingredients ensure a safe and non-toxic cleaning process, making it an excellent choice for households seeking greener cleaning alternatives. The Patanjali Green Flush Toilet Cleaner is easy to use, requiring just a simple application and brush to achieve optimal results. It not only cleans but also leaves a refreshing fragrance, ensuring your bathroom smells pleasant. Reflecting Patanjali’s commitment to quality and sustainability, this toilet cleaner offers a safe and effective way to keep your toilets clean without compromising on environmental responsibility."
    },
    {
        id:6,
        name:"AAstha Loban",
        price:"₹ 55",
        img:"https://www.patanjaliayurved.net/assets/product_images/400x500/1719996539loban30g1.png",
        mrp:"65",
        qunti:"30G",
        rew:"⭐⭐⭐",
        Des:"Patanjali Aastha Loban is a traditional aromatic resin used for its spiritual and therapeutic benefits. Derived from natural sources, Loban, also known as benzoin resin, has been used for centuries in various cultural rituals and practices to purify the environment and enhance spiritual experiences. When burned, Aastha Loban releases a soothing, fragrant smoke that is believed to cleanse the air, promote tranquility, and ward off negative energies. It is commonly used during meditation, prayers, and religious ceremonies to create a serene and uplifting atmosphere. Patanjali Aastha Loban is free from harmful chemicals and additives, ensuring a pure and authentic experience. Its calming aroma not only elevates the spiritual ambiance but also helps in reducing stress and anxiety, making it a valuable addition to any home or spiritual practice."
    },
    {
        id:7,
        name:"AAstha Gugal",
        price:"₹ 120",
        img:"https://www.patanjaliayurved.net/assets/product_images/400x500/1701406974AasthaGugal1.png",
        mrp:"140",
        qunti:"30G",
        rew:"⭐⭐⭐",
        Des:"Patanjali Aastha Gugal is a traditional aromatic resin known for its spiritual, medicinal, and therapeutic properties. Derived from the gum resin of the Commiphora wightii plant, Gugal has been used in Ayurvedic practices and spiritual rituals for centuries. When burned, Aastha Gugal releases a pleasant, earthy fragrance that is believed to purify the environment, enhance meditation, and promote a sense of tranquility and well-being. It is often used during prayers, meditation sessions, and religious ceremonies to create a serene and sacred atmosphere. Additionally, the smoke from Gugal is known to repel insects and purify the air. Patanjali ensures that Aastha Gugal is natural and free from harmful additives, providing an authentic and pure experience. Its calming aroma not only enhances the spiritual ambiance but also helps in reducing stress and anxiety, making it a valuable addition to any home or spiritual practice."
    },
    {
        id:8,
        name:"Aastha Sambrani Cup",
        price:"₹ 200",
        img:"https://www.patanjaliayurved.net/assets/product_images/400x500/1688794785SambraniCup1.png",
        mrp:"250",
        qunti:"152G",
        rew:"⭐⭐⭐",
        Des:"Patanjali Aastha Sambrani Cup is a convenient and traditional incense product designed to bring the rich, aromatic fragrance of natural resins and herbs into your home. Made from high-quality ingredients, including natural resins, herbs, and essential oils, these cups are crafted to ensure a long-lasting and pleasant aroma. When lit, Aastha Sambrani Cups release a fragrant smoke that purifies the air, creates a calming atmosphere, and is often used in religious rituals, meditation, and yoga practices. The ease of use—simply light the cup and allow it to smolder—makes it an excellent choice for those seeking a quick and effective way to enhance their environment. Patanjali’s commitment to quality ensures that Aastha Sambrani Cups are free from harmful chemicals, providing a safe and authentic aromatic experience that promotes relaxation, mental clarity, and spiritual upliftment."
    },
    {
        id:9,
        name:"Aastha Divya Hawan Samagri",
        price:"₹ 100",
        img:"https://www.patanjaliayurved.net/assets/product_images/400x500/16887286521.png",
        mrp:"150",
        qunti:"500G",
        rew:"⭐⭐⭐⭐",
        Des:"Patanjali Aastha Sambrani Cup is a convenient and traditional incense product designed to bring the rich, aromatic fragrance of natural resins and herbs into your home. Made from high-quality ingredients, including natural resins, herbs, and essential oils, these cups are crafted to ensure a long-lasting and pleasant aroma. When lit, Aastha Sambrani Cups release a fragrant smoke that purifies the air, creates a calming atmosphere, and is often used in religious rituals, meditation, and yoga practices. The ease of use—simply light the cup and allow it to smolder—makes it an excellent choice for those seeking a quick and effective way to enhance their environment. Patanjali’s commitment to quality ensures that Aastha Sambrani Cups are free from harmful chemicals, providing a safe and authentic aromatic experience that promotes relaxation, mental clarity, and spiritual upliftment.Divya Hawan Samagri is a meticulously crafted blend of natural herbs and materials used in the sacred practice of hawan, a ritualistic fire ceremony in Hindu tradition. This samagri, offered by Patanjali, contains a mix of aromatic substances, wood chips, dried herbs, and medicinal plants, each selected for its significance and benefits in the hawan process. The blend is designed to purify the environment, invoke positive energies, and enhance spiritual well-being. When burned in the hawan fire, Divya Hawan Samagri releases a fragrant smoke that is believed to cleanse the air, ward off negative energies, and create a serene and sacred atmosphere conducive to meditation and prayer. Patanjali ensures that this samagri is made from high-quality, natural ingredients, free from harmful chemicals, making it a pure and effective choice for spiritual ceremonies and rituals."
    },
    {
        id:10,
        name:"Aastha Cow Ghee",
        price:"₹ 150",
        img:"https://www.patanjaliayurved.net/assets/product_images/400x500/1688793287AasthaGhee200g1.png",
        mrp:"200",
        qunti:"200ML    ",
        rew:"⭐⭐⭐",
        Des:"Patanjali Cow Ghee is a premium dairy product renowned for its rich flavor, nutritional benefits, and traditional preparation methods. Made from pure cow's milk, this ghee is a staple in Indian households, valued for its high nutritional content and versatility in cooking. It is prepared using traditional methods to retain its natural aroma, taste, and essential nutrients. Patanjali Cow Ghee is rich in vitamins A, D, E, and K, and contains healthy fats that are beneficial for overall health. It is known to aid digestion, boost immunity, and promote brain function. Additionally, its high smoke point makes it ideal for frying and sautéing, while its distinctive flavor enhances the taste of various dishes, from curries and sweets to parathas and dals. Patanjali ensures that their cow ghee is free from preservatives and artificial additives, providing a pure and wholesome product that aligns with their commitment to quality and natural wellness."
    },
    {
        id:11,
        name:"Aastha Hawan Samagri",
        price:"₹ 60",
        img:"https://www.patanjaliayurved.net/assets/product_images/400x500/1688714322HawanSamigri250g1.png",
        mrp:"80",
        qunti:"250G    ",
        rew:"⭐⭐⭐⭐",
        Des:"Patanjali Aastha Sambrani Cup is a convenient and traditional incense product designed to bring the rich, aromatic fragrance of natural resins and herbs into your home. Made from high-quality ingredients, including natural resins, herbs, and essential oils, these cups are crafted to ensure a long-lasting and pleasant aroma. When lit, Aastha Sambrani Cups release a fragrant smoke that purifies the air, creates a calming atmosphere, and is often used in religious rituals, meditation, and yoga practices. The ease of use—simply light the cup and allow it to smolder—makes it an excellent choice for those seeking a quick and effective way to enhance their environment. Patanjali’s commitment to quality ensures that Aastha Sambrani Cups are free from harmful chemicals, providing a safe and authentic aromatic experience that promotes relaxation, mental clarity, and spiritual upliftment.Divya Hawan Samagri is a meticulously crafted blend of natural herbs and materials used in the sacred practice of hawan, a ritualistic fire ceremony in Hindu tradition. This samagri, offered by Patanjali, contains a mix of aromatic substances, wood chips, dried herbs, and medicinal plants, each selected for its significance and benefits in the hawan process. The blend is designed to purify the environment, invoke positive energies, and enhance spiritual well-being. When burned in the hawan fire, Divya Hawan Samagri releases a fragrant smoke that is believed to cleanse the air, ward off negative energies, and create a serene and sacred atmosphere conducive to meditation and prayer. Patanjali ensures that this samagri is made from high-quality, natural ingredients, free from harmful chemicals, making it a pure and effective choice for spiritual ceremonies and rituals."
    },
    {
        id:12,
        name:"Aastha Honey",
        price:"₹ 55",
        img:"https://www.patanjaliayurved.net/assets/product_images/400x500/1688794628Asthahoney100g1.png",
        mrp:"85",
        qunti:"100G   ",
        rew:"⭐⭐⭐",
        Des:"Patanjali Astha Honey is a premium product from Patanjali, a renowned brand known for its range of natural and Ayurvedic products. This honey is sourced from the nectar of various flowers, ensuring a rich and authentic flavor. It is carefully processed to retain its natural properties, making it a healthy and nutritious sweetener. Rich in antioxidants, vitamins, and minerals, Patanjali Astha Honey offers numerous health benefits, including boosting immunity, aiding digestion, and providing a natural source of energy. Its purity and quality make it a preferred choice for those seeking a natural alternative to refined sugars. Whether used in beverages, desserts, or as a spread, Patanjali Astha Honey enhances the taste and nutritional value of your food.  "
    },
    ]
    export default HerData;