import React from 'react';
import { Link } from 'react-router-dom';
import HerData from './Herbealdata';
import './Styles.css'; 

const Herballist = () => {
  return (
    <div className="container mt-5">
      <div className="row">
        {HerData.map((item, index) => (
          <div key={index} className="col-md-4 mb-4">
            <div className="card" style={{ height: "360px" }}>
              <img src={item.img} className="fixed-size-img card-img-top" alt={item.name} />
              <div className="card-body">
                <h5 className="card-title text-center">{item.name}</h5>
                <div className='d-flex justify-content-around'>
                  <h5 className="card-text text-success font-weight-bold">{item.price}</h5>
                  <p>{item.qunti}</p>
                  <strike className="text-danger"><p className="card-text text-danger">₹{item.mrp}</p></strike>
                </div>
                <p className='text-center'>{item.rew}</p>
              </div>
              <div className='text-center'>
                <Link to={`/herbaldetail/${item.id}`} className='butn'> <p>Buy Now  </p></Link>
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};

export default Herballist;
