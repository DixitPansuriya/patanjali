import React from 'react';
import { useParams } from 'react-router-dom';
import HerData from './Herbealdata';

const Herbaldetail = () => {
  const { id } = useParams();
  const item = HerData.find(data => data.id === parseInt(id));

  if (!item) {
    return <div>Item not found</div>;
  }

  return (
    <div className="container mt-5">
      <div className='d-flex justify-content-evenly'>
        <div>

<img  src={item.img} style={{height:"440px"}}/>

        </div>
        <div className='w-25'>
<h2>{item.name}</h2>
<div className='d-flex justify-content-around'>
  <h5 className='text-success'>{item.price}</h5>
 <strike className="text-danger"><h5>₹ {item.mrp}</h5></strike> 

</div>
<p>
  {item.Des}
</p>

        </div>
      </div>
    </div>
  );
};

export default Herbaldetail;
