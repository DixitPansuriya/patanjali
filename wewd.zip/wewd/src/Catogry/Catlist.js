import React from 'react'
import catogerydata from '../data/CatoeryData';
import Catogerycard from './Catogerycard';

const Catlist = () =>{
    return(
<div>
<h1 className='text-center mt-5 bg-main'>Top Deals & Offers</h1>
            <div className="product-list d-flex justify-content-evenly mt-5">



                {catogerydata.map(product => (
                    <Catogerycard key={product.id} product={product} />
                ))}

            </div>  

</div>
    );
}
export default Catlist;