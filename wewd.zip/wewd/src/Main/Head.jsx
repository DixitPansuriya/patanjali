import React from 'react'

export default function Head() {
  return (
    <div className='d-flex justify-content-around mt-2'>
      <div>
        <img src="https://www.patanjaliayurved.net/media/images/logo.svg" alt="" />
      </div>
      <div>
        <input type="text" name="" id="" placeholder='Search Products Here.....' style={{height:"40px",width:"350px"}}/>
        <button className='bg-main  ' style={{height:"40px",width:"50px",borderRadius:"2px"}}><i class="fas fa-search"></i></button>
      </div>
      <div className='d-flex gap-5 mt-2 fs-4'>
      <i class="fa-regular fa-heart"></i>
      <i class="fa-regular fa-user"></i>
      <i class="fa-solid fa-cart-shopping"></i>
      </div>
    </div>
  )
}
