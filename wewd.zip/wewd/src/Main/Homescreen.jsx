import React from 'react'
import Slider from './Slider'
import Category from './Catogery'
import ProductList from '../components/ProductList'
import Catlist from '../Catogry/Catlist'

export default function Homescreen() {
  return (
    <div>   
      <Slider/>
      <Category/>
      <ProductList/>
      <Catlist/>
    </div>
  )
}
