import React from 'react'

export default function Bar() {
  return (
    <div>
      <div>
        <div className='d-flex justify-content-center gap-5 mt-3 bg-main bar'>
            <a href="">Ayurvedic Medicine </a>
            <a href="">Foods</a>
            <a href="">Nutraceuticals</a>
            <a href=""> Personal Care</a>
            <a href="">Health Care</a>
            <a href="">Paridhan</a>
            <a href="">About Us</a>
            <a href="">Contact</a>
            

        </div>
      </div>
    </div>
  )
}
