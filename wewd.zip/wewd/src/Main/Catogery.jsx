import React from 'react';
import CaData from '../data/CatData';


const Category = () => {
    return (
        <div className="container">
            <h3 className='text-center mt-5 text-success'> 
                Select by category
            </h3>
            <div className="row">
                {CaData.map(category => (
                    <div key={category.id} className="col-md-2 mb-4 mt-2">
                        <div className="border rounded p-2 d-flex align-items-center gap-2 border-success">
                            <img src={category.img} alt={category.name} style={{ width: 50, height: 50 }} className="rounded-circle mr-2" />
                            <span>{category.name}</span>
                        </div>
                    </div>
                ))}
            </div>
        </div>
    );
}

export default Category;
