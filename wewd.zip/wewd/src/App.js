import React from 'react';
import { BrowserRouter as Router, Route, Routes } from 'react-router-dom';
import ProductList from './components/ProductList';
import ProductDetails from './components/ProductDetails';
import Head from './Main/Head';
import Bar from './Main/Bar';

import Homescreen from './Main/Homescreen';

import Catlist from './Catogry/Catlist';
import Herballist from './CYdata/Herballist';
import Herbaldetail from './CYdata/Herbaldetail';

const App = () => {
    return (
        <Router>
          <Head/>
          <Bar/>

            <div className="app">
                <Routes>            
                    <Route path="/" element={<Homescreen/>}/>
                    <Route path="/" element={<ProductList />} />
                    <Route path="/product/:id" element={<ProductDetails />} />
                    <Route path="/" element={<Catlist/>}/>
                   <Route path="/item" element={<Herballist/>}/>
               <Route path='/herbaldetail/:id' element={<Herbaldetail/>}/>

                  
                </Routes>
            </div>
        </Router>
    );
};

export default App;
