import React, { useState } from 'react';
import { useParams } from 'react-router-dom';
import SaData from '../data/SaData';





const Btnstyle={
    color:"white",
    backgroundColor:"#186C38",
}

const ProductDetails = () => {
    const { id } = useParams();
    const product = SaData.find(p => p.id === parseInt(id));

    return (
        <div className="product-details ">
            <div className='row '>
                <div className='d-flex '>
                <div className='col-lg-6 col-md-4 col-sm-12 overflow-hidden'>
                    <img src={product.img} alt={product.name} style={{width:"60%"}}/>
                </div>
                <div className='mt-5'>
                    <h2>{product.name}</h2>
                    <p>{product.price}</p>
                    <p>{product.rew}</p>
                    <p>{product.Des}</p>
                    <button className='btn  btn-lg ' style={Btnstyle}>Buy now</button>
                <div>
               

                </div>
                </div>
       
                </div>
           
            </div>


        </div>
    );
};

export default ProductDetails;
