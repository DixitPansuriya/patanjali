import React from 'react';
import ProductCard from './ProductCard';
import SaData from '../data/SaData';


const ProductList = () => {
    return (
        <div>
            <h1 className='text-center mt-5 bg-main'>Top Deals & Offers</h1>
            <div className="product-list d-flex justify-content-evenly mt-5">



                {SaData.map(product => (
                    <ProductCard key={product.id} product={product} />
                ))}

            </div>
           
        </div>
    );
};

export default ProductList;
